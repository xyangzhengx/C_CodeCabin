#define _CRT_SECURE_NO_WARNINGS 1
#include "Contacts_Address.h"
int is_full_Contact(const struct Contact_Person* Con)
{
	if ((Con->size) < (Con->capacity))
	{
		return 0;
	}
	else
		return -1;
}