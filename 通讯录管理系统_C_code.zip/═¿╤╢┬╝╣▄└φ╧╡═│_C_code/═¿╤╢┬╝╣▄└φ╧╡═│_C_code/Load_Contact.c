#define _CRT_SECURE_NO_WARNINGS 1
#include "Contacts_Address.h"
void Load_Contact(struct Contact_Person* Con)
{
	FILE* pf = fopen("contact.txt", "rb");
	if (pf == NULL)
	{
		perror("Load_Contact");
		return;
	}
	struct Person tmp = {0};
	while (fread(&tmp, sizeof(struct Person), 1, pf))
	{
		if (is_full_Contact(Con) == -1)
		{
			Increase_Contact(Con);
		}
		Con->data[Con->size] = tmp;
		Con->size++;
	}
	fclose(pf);
	pf = NULL;
	printf("�������ݳɹ���\n");
}
