#define _CRT_SECURE_NO_WARNINGS 1
#include "Contacts_Address.h"
void Save_Contact(const struct Contact_Person* Con)
{
	FILE* pf = fopen("contact.txt","wb");
	if (pf == NULL)
	{
		perror("Save_Contact");
		return;
	}
	else
	{
		for (int i = 0; i < Con->size; i++)
		{
			fwrite(Con->data+i,sizeof(struct Person), 1, pf);
		}
	}
	fclose(pf);
	pf = NULL;
	printf("����ɹ���\n");
}