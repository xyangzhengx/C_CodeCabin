#define _CRT_SECURE_NO_WARNINGS 1
#include "Contacts_Address.h"
int is_exist_Contact(const struct Contact_Person* Con,char arr[])
{
	int i = 0;
	for (i = 0; i < (Con->size); i++)
	{
		if (strcmp((Con->data)[i].name,arr)==0)
		{
			return i;
		}
	}
	return -1;
}