#define _CRT_SECURE_NO_WARNINGS 1
#include "Contacts_Address.h"
void Show_Contact(const struct Contact_Person* Con)
{
	int i = 0;
	printf("%-12s\t%-5s\t%-5s\t%-12s\t%-20s\n","name","sex","age","tel","add");
	for (i = 0; i < (Con->size); i++)
	{
		printf("%-12s\t%-5s\t%-5d\t%-12s\t%-20s\n", (Con->data)[i].name, (Con->data)[i].sex,(Con->data)[i].age,(Con->data)[i].tel, (Con->data)[i].add);
	}
}
