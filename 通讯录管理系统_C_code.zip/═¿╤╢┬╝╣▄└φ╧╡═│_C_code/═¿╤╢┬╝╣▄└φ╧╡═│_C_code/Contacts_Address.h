#define _CRT_SECURE_NO_WARNINGS 1
#define MAX_NAME 20
#define MAX_SEX 10
#define MAX_TELE 12
#define MAX_ADDR 30
#define MAX 1000
#define DEFAULT_SZ 3
#define INC_SZ 2
#include <stdio.h>
#include <string.h>
struct Person {
	char name[MAX_NAME];
	char sex[MAX_SEX];
	int age;
	char tel[MAX_TELE];
	char add[MAX_ADDR];
};
struct Contact_Person {
	int size;
	int capacity;
	struct Person* data;
};
void Init_Contact(struct Contact_Person* Con);
void Add_Contact(struct Contact_Person* Con);
void Increase_Contact(struct Contact_Person* Con);
int is_full_Contact(const struct Contact_Person* Con);
void Delete_Contact(struct Contact_Person* Con);
int is_exist_Contact(const struct Contact_Person* Con,const char* arr);
void Search_Contact(const struct Contact_Person* Con);
void Edit_Contact(struct Contact_Person* Con);
void Show_Contact(const struct Contact_Person* Con);
void Sort_Contact(const struct Contact_Person* Con);
void Save_Contact(const struct Contact_Person* Con);
void Load_Contact(struct Contact_Person* Con);