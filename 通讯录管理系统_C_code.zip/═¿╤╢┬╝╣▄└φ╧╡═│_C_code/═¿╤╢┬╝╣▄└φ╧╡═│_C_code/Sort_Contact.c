#define _CRT_SECURE_NO_WARNINGS 1
#include "Contacts_Address.h"
void Sort_Contact(const struct Contact_Person* Con)
{
	
}