#define _CRT_SECURE_NO_WARNINGS 1
#include "Contacts_Address.h"
//ʵ��һ��ͨѶ¼����ϵͳ
//���ܰ�������ɾ��ı������
enum _Fun {
	EXIT,
	ADD,
	DELETE,
	SEARCH,
	EDIT,
	SHOW,
	SORT,
	SAVE
};
void menu()
{
	printf("*****************************\n");
	printf("****1.Add        2.Delete****\n");
	printf("****3.Search     4.Edit  ****\n");
	printf("****5.Show       6.Sort  ****\n");
	printf("****7.Save       0.Exit  ****\n");
	printf("*****************************\n");
}
int main()
{
	int input = 0;
	//��ʼ��ͨѶ¼
	struct Contact_Person Con;
	Init_Contact(&Con);
	do
	{
		menu();
		printf("Please Choose:");
		scanf("%d",&input);
		switch (input)
		{
			case EXIT:
				printf("Exit is Successing!\n");
				break;
			case ADD:
				Add_Contact(&Con);
				break;
			case DELETE:
				Delete_Contact(&Con);
				break;
			case SEARCH:
				Search_Contact(&Con);
				break;
			case EDIT:
				Edit_Contact(&Con);
				break;
			case SHOW:
				Show_Contact(&Con);
				break;
			case SORT:
				Sort_Contact(&Con);
				break;
			case SAVE:
				Save_Contact(&Con);
				break;
			default:
				printf("There is an incorrect input\n");
				break;
		}
	} while (input);
	return 0;
}
