#define _CRT_SECURE_NO_WARNINGS 1
#include "Contacts_Address.h"
void Init_Contact(struct Contact_Person* Con)
{
	Con->size = 0;
	Con->capacity = DEFAULT_SZ;
	struct Person* ptr= (struct Person*)malloc(DEFAULT_SZ * sizeof(struct Person));
	if (ptr != NULL)
	{
		Con->data = ptr;
		printf("��ʼ���ɹ���\n");
	}
	else {
		perror("��ʼ��ʧ��");
	}
	Load_Contact(Con);
}