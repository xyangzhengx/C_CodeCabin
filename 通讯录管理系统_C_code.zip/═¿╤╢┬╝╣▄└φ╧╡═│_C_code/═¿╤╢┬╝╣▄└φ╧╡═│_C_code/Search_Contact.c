#define _CRT_SECURE_NO_WARNINGS 1
#include "Contacts_Address.h"
void Search_Contact(const struct Contact_Person* Con) {
	char arr[MAX_NAME] = { 0 };
	printf("������Ҫ���ҵ���������");
	scanf("%s", arr);
	int ret = is_exist_Contact(Con, arr);
	if (ret==-1)
	{
		printf("���޴���\n");
		return;
	}
	else
	{
		printf("%-12s\t%-5s\t%-5s\t%-12s\t%-20s\n", "name", "sex", "age", "tel", "add");
		printf("%-12s\t%-5s\t%-5d\t%-12s\t%-20s\n", (Con->data)[ret].name, (Con->data)[ret].sex, (Con->data)[ret].age, (Con->data)[ret].tel, (Con->data)[ret].add);
	}
}
