#define _CRT_SECURE_NO_WARNINGS 1
#include "Contacts_Address.h"
void Increase_Contact(struct Contact_Person* Con)
{
	Con->capacity += INC_SZ;
	struct Person* ptr = (struct Person*)realloc(Con->data,(Con->capacity) * sizeof(struct Person));
	if (ptr != NULL)
	{
		Con->data = ptr;
		printf("���ݳɹ���\n");
	}
	else {
		perror("����ʧ��");
	}
}